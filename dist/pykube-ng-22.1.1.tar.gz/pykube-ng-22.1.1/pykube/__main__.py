from .console import main

main()
